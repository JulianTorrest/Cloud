# Event-Management-System
Event Management System using Flask and Sqlite3
